// =========================================================================
// ujt_garagem — NUI (painel de setup)
// Overlay informativo (não captura input; a marcação é feita in-game).
// =========================================================================
function post(name, body) {
	return fetch(`https://ujt_garagem/${name}`, {
		method: "POST", headers: { "Content-Type": "application/json; charset=UTF-8" },
		body: JSON.stringify(body || {}),
	}).catch(() => {});
}
function esc(t) { const d = document.createElement("div"); d.textContent = t == null ? "" : String(t); return d.innerHTML; }

window.closePanel = function () {
	document.getElementById("panel").classList.add("hidden");
	post("panelClose");
};
window.retrieveCar = function (id) {
	document.getElementById("panel").classList.add("hidden");
	post("panelRetrieve", { id: id });
};

document.addEventListener("keyup", (e) => {
	if (e.key === "Escape" && !document.getElementById("panel").classList.contains("hidden")) {
		closePanel();
	}
});

function renderPanel(vehicles, used, total) {
	document.getElementById("p-cap").textContent = `${used} / ${total} vagas`;
	const list = document.getElementById("p-list");
	if (!vehicles || vehicles.length === 0) {
		list.innerHTML = `<div class="pempty">Sua garagem está vazia.<br>Guarde um carro na entrada.</div>`;
		return;
	}
	list.innerHTML = vehicles.map(v => `
		<div class="pitem">
			<div class="icon">🚗</div>
			<div class="info">
				<div class="name">${esc(v.label)}</div>
				<div class="meta">Vaga ${esc(v.spot)}</div>
			</div>
			<button class="pbtn" onclick="retrieveCar(${v.id})">Retirar</button>
		</div>`).join("");
}

window.addEventListener("message", (ev) => {
	const m = ev.data || {};
	const el = document.getElementById("setup");

	if (m.action === "panelOpen") {
		renderPanel(m.vehicles, m.used, m.total);
		document.getElementById("panel").classList.remove("hidden");
		return;
	} else if (m.action === "panelClose") {
		document.getElementById("panel").classList.add("hidden");
		return;
	}

	if (m.action === "setupOpen") {
		el.classList.remove("hidden");
	} else if (m.action === "setupClose") {
		el.classList.add("hidden");
	} else if (m.action === "setupUpdate") {
		const ent = document.getElementById("st-entrance");
		const spots = document.getElementById("st-spots");
		if (ent) {
			ent.textContent = m.entrance ? "✓ definida" : "✗ não definida";
			ent.classList.toggle("on", !!m.entrance);
		}
		if (spots) spots.textContent = (m.spots || 0) + " / " + (m.max || 12);
	}
});
