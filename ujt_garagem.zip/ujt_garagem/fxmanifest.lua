fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'UJT'
description 'ujt_garagem - Garagem pessoal instanciada com carros visíveis estacionados (vRPex)'
version '0.1.0'

shared_scripts {
	'@vrp/lib/utils.lua',
	'config.lua',
}

client_scripts {
	'client/main.lua',
}

ui_page 'html/index.html'

files {
	'html/index.html',
	'html/style.css',
	'html/app.js',
}

server_scripts {
	'@oxmysql/lib/MySQL.lua',
	'server/main.lua',
}

dependencies {
	'vrp',
	'oxmysql',
}

optional_dependency 'ox_target'
