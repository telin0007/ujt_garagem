# ujt_garagem

Garagem pessoal para **vRPex**, criada do zero e separada da garagem principal do servidor.
Cada jogador **define no jogo** a entrada e as vagas da própria garagem, guarda os veículos,
e eles ficam **estacionados e visíveis** — com os acessórios do **bs_montasom** aplicados.

---

## Índice
- [Recursos](#recursos)
- [Dependências](#dependências)
- [Instalação](#instalação)
- [Comandos](#comandos)
- [Como usar (passo a passo)](#como-usar-passo-a-passo)
- [Configuração (`config.lua`)](#configuração-configlua)
- [Como funciona (arquitetura)](#como-funciona-arquitetura)
- [Integrações](#integrações)
- [Banco de dados](#banco-de-dados)
- [Eventos e interfaces](#eventos-e-interfaces)
- [Desempenho (resmon)](#desempenho-resmon)
- [Solução de problemas](#solução-de-problemas)

---

## Recursos

- **Garagem por jogador (instanciada por dono):** cada um monta a sua; ninguém mexe na do outro.
- **Você define as coordenadas no jogo** — sem coordenadas fixas no arquivo.
  - Um **carro-fantasma** mostra onde a vaga vai ficar antes de confirmar.
  - Trava contra vagas coladas (distância mínima) pra os carros não empilharem.
- **Carros ficam estacionados e visíveis** nas vagas (em rede/networked).
- **NUI bonita** pra listar e retirar os veículos.
- **Preserva a customização** do veículo (cor, mods, rodas, neon, fumaça, etc.).
- **Acessórios do bs_montasom** aparecem no carro guardado e voltam ao retirar.
- **Identidade por dono + modelo** (a placa **não** é usada — ideal pra bases com placas duplicadas).
- **Integração com skips_garagem:** tirar o carro de lá remove ele daqui (não duplica).
- **Loop otimizado** para resmon baixo.

---

## Dependências

| Recurso | Obrigatório | Para quê |
|---|:---:|---|
| `vrp` (vRPex) | ✅ | Base / identidade do jogador |
| `oxmysql` | ✅ | Persistência no banco |
| `ox_target` | ⭕ opcional | Interação por alvo (guardar/abrir/retirar). Sem ele, usa marcador + tecla **E** |
| `bs_montasom` | ⭕ opcional | Acessórios de som nos carros guardados |
| `skips_garagem` | ⭕ opcional | Integração anti-duplicação |

---

## Instalação

1. Coloque a pasta `ujt_garagem` em `resources/[ujt]/`.
2. Adicione no `server.cfg`:
   ```
   ensure ujt_garagem
   ```
3. As tabelas são criadas **automaticamente** ao ligar (não precisa importar SQL).
4. Garanta que `vrp`, `oxmysql` (e, se quiser, `ox_target` / `bs_montasom`) iniciem **antes**.

---

## Comandos

| Comando | O que faz |
|---|---|
| `/garagem` | Abre o painel da garagem (perto da entrada) |
| `/garagemsetup` | Entra no modo de configuração pra definir entrada e vagas |
| `/garagemapagar` | Apaga a garagem (bloqueia se houver carros guardados) |
| `/garagemapagar tudo` | Apaga a garagem **e** todos os carros guardados |

> Os nomes dos comandos são configuráveis em `config.lua`.

---

## Como usar (passo a passo)

### 1) Montar a garagem — `/garagemsetup`
No modo de configuração aparece um **carro-fantasma** à sua frente:

| Tecla | Ação |
|---|---|
| **E** | Adiciona uma vaga onde o fantasma está |
| **G** | Define a **entrada** (sua posição atual) |
| **Backspace** | Remove a **última** vaga |
| **Delete** | Limpa tudo e recomeça |
| **Enter** | **Salva** (precisa de entrada + pelo menos 1 vaga) |
| **ESC** | Cancela sem salvar |

> Ande alguns passos entre uma vaga e outra — o sistema **recusa vagas muito próximas**
> (evita carro em cima de carro). Ao salvar aparece *"Entrada e **X** vaga(s) definidas"*.

### 2) Guardar um carro
Chegue com o veículo perto da entrada e use **Guardar veículo** (ox_target) ou a tecla **E**.

### 3) Ver / retirar
- `/garagem` (a pé, perto da entrada) abre o painel com a lista.
- Clique em **Retirar** — o carro sai dirigível na entrada, com a customização e o som de volta.
- Com ox_target, dá pra retirar clicando direto no carro estacionado.

---

## Configuração (`config.lua`)

```lua
Config.Locale        = "pt-BR"
Config.OpenCommand   = "garagem"        -- abre/gerencia
Config.SetupCommand  = "garagemsetup"   -- define coordenadas
Config.DeleteCommand = "garagemapagar"  -- apaga (use "tudo" pra apagar carros junto)

Config.UseOxTarget   = true             -- interação via ox_target (senão marcador + E)
Config.MarkerKey     = 38               -- tecla E
Config.DisplayRadius = 60.0             -- distância pra exibir os carros estacionados
Config.InteractDist  = 2.5              -- distância pra poder GUARDAR o carro

Config.MaxVehiclesPerPlayer = 12        -- máx. de carros/vagas por jogador
Config.MinSpotDistance      = 4.5       -- distância mínima entre vagas (anti-empilhamento)

Config.GhostModel   = "sultan"          -- modelo do carro-fantasma no setup
Config.GhostForward = 3.5               -- distância à frente onde o fantasma aparece

Config.Blip = { sprite = 357, color = 3, scale = 0.9, label = "Minha Garagem" }

-- Ajuste pro seu sistema de notificação:
Config.Notify = function(source, typ, msg, time)
    TriggerClientEvent("Notify", source, typ or "aviso", msg or "", time or 4000)
end
```

| Parâmetro | Efeito prático |
|---|---|
| `DisplayRadius` | De quão longe os carros parados aparecem/carregam |
| `InteractDist` | Quão perto precisa estar pra guardar (menor = mais coladinho) |
| `MaxVehiclesPerPlayer` | Limite de vagas e de carros guardados |
| `MinSpotDistance` | Espaço mínimo entre vagas no setup |
| `GhostForward` | Onde o carro-fantasma nasce em relação a você |

---

## Como funciona (arquitetura)

- **Identidade = `owner_id` (id do player) + modelo do veículo.**
  A **placa não é usada** como identidade (a base tem placas duplicadas, então placa causa conflito).
- **Carros exibidos são em rede (networked).**
  Isso permite que o **bs_montasom** os enxergue e aplique os acessórios. Consequência: **outros
  jogadores também veem** os carros parados (troca aceita pra o som funcionar — "Opção A").
- **Limpeza de acessórios ao deletar:** antes de remover qualquer carro (guardar, trocar de vaga,
  sair da área), o script manda o bs_montasom remover os objetos presos — assim nada fica órfão no chão.

Fluxo resumido:

```
GUARDAR   -> salva props no banco (owner+model) -> remove o carro real + acessórios (sem órfãos)
PARADO    -> spawna o carro na vaga (networked) -> pede ao bs_montasom pra reaplicar o som
RETIRAR   -> apaga a linha do banco -> spawna dirigível na entrada -> reaplica customização + som
SAIR (raio)-> remove os carros parados de forma limpa
```

---

## Integrações

### bs_montasom (acessórios de som)
- O `ujt_garagem` chama **`bs_montasom:loadForOwner(netId, modelName)`** ao exibir/retirar o carro.
- Esse evento foi adicionado no `bs_montasom/server.lua` e casa por **dono + modelo** (sem depender da placa).
- Ao deletar um carro, chama **`bs_montasom:deletePropsClient(netId)`** pra não deixar props soltos.

### skips_garagem (anti-duplicação)
- No `skips_garagem` (dentro de `spawnVeh`/`spawnVeh2`) foi adicionada **uma linha** que dispara
  **`ujt_garagem:externalTakeout(modelHash)`** quando um carro é retirado de lá.
- O servidor do `ujt_garagem` então remove esse mesmo modelo da garagem pessoal do jogador,
  evitando ficar com o carro duplicado nas duas garagens.

> Essas integrações são opcionais: se `bs_montasom`/`skips_garagem` não existirem, o resto funciona normal.

---

## Banco de dados

Criadas automaticamente (`CREATE TABLE IF NOT EXISTS`):

### `ujt_garagem_config` — a garagem de cada jogador
| Coluna | Tipo | Descrição |
|---|---|---|
| `owner_id` | INT (PK) | ID do jogador (dono) |
| `entrance` | LONGTEXT | JSON `{x,y,z,w}` da entrada |
| `spots` | LONGTEXT | JSON com a lista de vagas `[{x,y,z,w}, ...]` |
| `updated_at` | TIMESTAMP | Última alteração |

### `ujt_garagem_vehicles` — os carros guardados
| Coluna | Tipo | Descrição |
|---|---|---|
| `id` | INT (PK, auto) | ID do registro |
| `owner_id` | INT | Dono |
| `model` | VARCHAR(60) | Hash do modelo (identidade junto com o dono) |
| `plate` | VARCHAR(12) | **Não usada** como identidade (legado) |
| `props` | LONGTEXT | JSON com a customização + acessórios visuais |
| `spot` | INT | Índice da vaga (0..N-1) |
| `stored_at` | TIMESTAMP | Quando foi guardado |

---

## Eventos e interfaces

### Servidor (Tunnel)
| Nome | Retorno | Uso |
|---|---|---|
| `getConfig` | `{ entrance, spots }` | Config do jogador |
| `getStored` | lista de veículos | Carros guardados do jogador |

### Servidor (eventos de rede)
| Evento | Args | Ação |
|---|---|---|
| `ujt_garagem:saveConfig` | `entrance, spots` | Salva entrada e vagas |
| `ujt_garagem:store` | `{ model, props }` | Guarda o veículo atual |
| `ujt_garagem:retrieve` | `vehId` | Retira o veículo |
| `ujt_garagem:deleteGarage` | `wipeVehicles` | Apaga a garagem (e carros se `true`) |
| `ujt_garagem:externalTakeout` | `modelHash` | (skips_garagem) remove modelo da garagem pessoal |

### Cliente (eventos de rede)
| Evento | Args | Ação |
|---|---|---|
| `ujt_garagem:configSaved` | `{ entrance, spots }` | Atualiza a config local |
| `ujt_garagem:refresh` | — | Recarrega os carros parados |
| `ujt_garagem:spawnDrivable` | `{ model, props }` | Spawna o carro retirado |

---

## Desempenho (resmon)

O loop principal só acelera quando há algo pra desenhar/interagir:

| Situação | Intervalo |
|---|---|
| Longe / sem garagem | `Wait(1000)` |
| Dentro do raio, com **ox_target** | `Wait(500)` |
| Dentro do raio, longe da entrada (sem ox_target) | `Wait(300)` |
| Coladinho na entrada (desenhando) | `Wait(0)` |

Com `ox_target` ativo, o resmon parado na garagem fica praticamente **0.00ms**.

---

## Solução de problemas

| Sintoma | Causa provável / solução |
|---|---|
| Não aparece **E** pra guardar | Chegue mais perto (`InteractDist`); confira se a entrada foi definida no setup |
| Carros **empilhados** nas vagas | Vagas criadas muito perto — refaça o setup afastando-as (a trava `MinSpotDistance` ajuda) |
| Só algumas vagas "salvam" | Veja o número em *"X vaga(s) definidas"* ao salvar; vagas coladas parecem uma só |
| Carro sai **sem som** | `bs_montasom` precisa estar ligado; o carro é spawnado em rede pra ele aplicar |
| Itens do som ficam **no chão** | Corrigido: os props são removidos antes de deletar o carro |
| Carro **duplicado** com a outra garagem | Integração `skips_garagem` precisa estar aplicada (linha em `spawnVeh`) |
| Painel não abre / mouse "preso" | Cache da NUI — os arquivos usam `?v=N`; suba o número se editar o HTML/JS |

---

## Estrutura de arquivos

```
ujt_garagem/
├── fxmanifest.lua
├── config.lua
├── README.md
├── client/
│   └── main.lua          # setup, exibição, guardar/retirar, integrações
├── server/
│   └── main.lua          # banco, config, store/retrieve, externalTakeout
└── html/
    ├── index.html
    ├── style.css
    └── app.js            # painel (lista/retirar)
```

---

*Feito para o servidor (vRPex). Identidade por dono + modelo; carros em rede para compatibilidade com o bs_montasom.*
