-- =========================================================================
-- ujt_garagem — CLIENT
-- O jogador DEFINE a própria garagem (entrada + vagas) via painel de setup,
-- e os carros guardados aparecem estacionados e visíveis (instanciados).
-- =========================================================================
local Tunnel = module("vrp", "lib/Tunnel")
local Proxy = module("vrp", "lib/Proxy")
vRP = Proxy.getInterface("vRP")
local vSERVER = Tunnel.getInterface("ujt_garagem")

local hasOxTarget = GetResourceState("ox_target") == "started"
local myGarage = { entrance = nil, spots = {} }   -- config do jogador
local displays = {}   -- [dbId] = entity (carros estacionados)
local shown = false
local myBlip = nil
local entranceZone = nil     -- id da zona ox_target da entrada
local storeCurrent           -- forward declaration (usada no refreshBlip)
local openPanel              -- forward declaration (usada no refreshBlip)

local function notify(typ, msg, time) TriggerEvent("Notify", typ or "aviso", msg or "", time or 4000) end

local function loadModel(model)
	local hash = type(model) == "number" and model or (tonumber(model) or GetHashKey(model))
	if not IsModelInCdimage(hash) then return nil end
	RequestModel(hash)
	local t = 0
	while not HasModelLoaded(hash) and t < 200 do Wait(10) t = t + 1 end
	return HasModelLoaded(hash) and hash or nil
end

local function drawText3D(c, text)
	local on, x, y = World3dToScreen2d(c.x, c.y, c.z)
	if not on then return end
	SetTextScale(0.34, 0.34); SetTextFont(4); SetTextCentre(true)
	SetTextColour(255, 255, 255, 220); SetTextEntry("STRING")
	AddTextComponentString(text); DrawText(x, y)
end

-- ---------------------------------------------------------------------------
-- Props (customização)
-- ---------------------------------------------------------------------------
-- Captura COMPLETA da customização (cor, RGB custom, acabamento, mods, wheels,
-- tint, neon, faróis, fumaça de pneu, extras, livery, placa).
local function getProps(veh)
	SetVehicleModKit(veh, 0)
	local props = {
		model = GetEntityModel(veh),
		plate = GetVehicleNumberPlateText(veh),
		plateIndex = GetVehicleNumberPlateTextIndex(veh),
		wheelType = GetVehicleWheelType(veh),
		windowTint = GetVehicleWindowTint(veh),
		livery = GetVehicleLivery(veh),
		wheelVariation = GetVehicleModVariation(veh, 23),
		mods = {}, toggles = {}, extras = {}, neon = {},
	}
	local c1, c2 = GetVehicleColours(veh); props.color1 = c1; props.color2 = c2
	local pe, wc = GetVehicleExtraColours(veh); props.pearl = pe; props.wheelColor = wc

	if GetIsVehiclePrimaryColourCustom(veh) then local r,g,b = GetVehicleCustomPrimaryColour(veh); props.customPrimary = { r, g, b } end
	if GetIsVehicleSecondaryColourCustom(veh) then local r,g,b = GetVehicleCustomSecondaryColour(veh); props.customSecondary = { r, g, b } end
	local pt1, mc1, pp1 = GetVehicleModColor_1(veh); props.modColor1 = { pt1, mc1, pp1 }
	local pt2, mc2 = GetVehicleModColor_2(veh); props.modColor2 = { pt2, mc2 }

	for i = 0, 3 do props.neon[i + 1] = IsVehicleNeonLightEnabled(veh, i) end
	local nr, ng, nb = GetVehicleNeonLightsColour(veh); props.neonColor = { nr, ng, nb }
	local tr, tg, tb = GetVehicleTyreSmokeColor(veh); props.tyreSmoke = { tr, tg, tb }

	for m = 0, 48 do props.mods[tostring(m)] = GetVehicleMod(veh, m) end
	for m = 17, 22 do props.toggles[tostring(m)] = IsToggleModOn(veh, m) end
	for e = 0, 20 do if DoesExtraExist(veh, e) then props.extras[tostring(e)] = IsVehicleExtraTurnedOn(veh, e) == 1 end end
	return props
end

local function applyProps(veh, props)
	if not props then return end
	SetVehicleModKit(veh, 0)
	if props.plate then SetVehicleNumberPlateText(veh, props.plate) end
	if props.plateIndex then SetVehicleNumberPlateTextIndex(veh, props.plateIndex) end

	-- cores
	if props.color1 ~= nil and props.color2 ~= nil then SetVehicleColours(veh, props.color1, props.color2) end
	if props.pearl ~= nil then SetVehicleExtraColours(veh, props.pearl, props.wheelColor or 0) end
	if props.modColor1 then SetVehicleModColor_1(veh, props.modColor1[1] or 0, props.modColor1[2] or 0, props.modColor1[3] or 0) end
	if props.modColor2 then SetVehicleModColor_2(veh, props.modColor2[1] or 0, props.modColor2[2] or 0) end
	if props.customPrimary then SetVehicleCustomPrimaryColour(veh, props.customPrimary[1], props.customPrimary[2], props.customPrimary[3]) end
	if props.customSecondary then SetVehicleCustomSecondaryColour(veh, props.customSecondary[1], props.customSecondary[2], props.customSecondary[3]) end

	if props.windowTint ~= nil then SetVehicleWindowTint(veh, props.windowTint) end
	if props.wheelType ~= nil then SetVehicleWheelType(veh, props.wheelType) end
	if props.livery ~= nil and props.livery >= 0 then SetVehicleLivery(veh, props.livery) end

	-- extras
	if props.extras then for e, on in pairs(props.extras) do if DoesExtraExist(veh, tonumber(e)) then SetVehicleExtra(veh, tonumber(e), on and 0 or 1) end end end

	-- mods (17-22 são toggles, tratados à parte)
	if props.mods then
		for m, v in pairs(props.mods) do
			m = tonumber(m)
			if not (m >= 17 and m <= 22) then
				SetVehicleMod(veh, m, v, (m == 23 or m == 24) and (props.wheelVariation == true) or false)
			end
		end
	end
	if props.toggles then for m, on in pairs(props.toggles) do ToggleVehicleMod(veh, tonumber(m), on == true) end end

	-- neon
	if props.neon then for i, on in pairs(props.neon) do SetVehicleNeonLightEnabled(veh, tonumber(i) - 1, on == true) end end
	if props.neonColor then SetVehicleNeonLightsColour(veh, props.neonColor[1] or 255, props.neonColor[2] or 0, props.neonColor[3] or 0) end

	-- fumaça de pneu
	if props.tyreSmoke then SetVehicleTyreSmokeColor(veh, props.tyreSmoke[1] or 255, props.tyreSmoke[2] or 255, props.tyreSmoke[3] or 255) end
end

-- ---------------------------------------------------------------------------
-- Exibir / limpar carros estacionados
-- ---------------------------------------------------------------------------
-- Deleta um veículo removendo ANTES os acessórios do bs_montasom presos nele
-- (senão os props ficam órfãos no chão).
local function deleteVehClean(ent)
	if not ent or not DoesEntityExist(ent) then return end
	TriggerEvent("bs_montasom:deletePropsClient", VehToNet(ent))
	DeleteEntity(ent)
end

local function clearDisplays()
	for _, e in pairs(displays) do deleteVehClean(e) end
	displays = {}
	shown = false
end

-- Há um veículo REAL (que não é display nosso) ocupando a vaga? (evita z-fighting/piscar)
local function realVehicleAtSpot(spot)
	for _, v in ipairs(GetGamePool("CVehicle")) do
		if DoesEntityExist(v) and #(GetEntityCoords(v) - vector3(spot.x, spot.y, spot.z)) < 2.2 then
			local ours = false
			for _, d in pairs(displays) do if d == v then ours = true break end end
			if not ours then return true end
		end
	end
	return false
end

local function spawnDisplay(item)
	local spot = myGarage.spots[(item.spot or 0) + 1]
	if not spot then return end
	-- não duplica: remove display antigo dessa mesma vaga/id (limpando os props)
	if displays[item.id] and DoesEntityExist(displays[item.id]) then deleteVehClean(displays[item.id]) displays[item.id] = nil end
	-- não sobrepõe carro real (evita piscar)
	if realVehicleAtSpot(spot) then return end
	local hash = loadModel(item.props and item.props.model or item.model)
	if not hash then return end
	-- EM REDE (networked) para o bs_montasom enxergar e aplicar os acessórios
	local veh = CreateVehicle(hash, spot.x, spot.y, spot.z, spot.w or 0.0, true, false)
	local nt = 0
	NetworkRegisterEntityAsNetworked(veh)
	while not NetworkGetEntityIsNetworked(veh) and nt < 50 do NetworkRegisterEntityAsNetworked(veh) Wait(1) nt = nt + 1 end
	SetEntityAsMissionEntity(veh, true, true)
	SetVehicleOnGroundProperly(veh)
	applyProps(veh, item.props)
	SetVehicleDoorsLocked(veh, 2); SetVehicleEngineOn(veh, false, true, true)
	FreezeEntityPosition(veh, true); SetEntityInvincible(veh, true)
	SetNetworkIdCanMigrate(VehToNet(veh), true); SetNetworkIdExistsOnAllMachines(VehToNet(veh), true)
	SetModelAsNoLongerNeeded(hash)
	displays[item.id] = veh
	-- reaplica os acessórios do bs_montasom (por DONO + MODELO, sem placa)
	SetTimeout(800, function()
		if DoesEntityExist(veh) then
			TriggerServerEvent("bs_montasom:loadForOwner", VehToNet(veh), GetDisplayNameFromVehicleModel(GetEntityModel(veh)))
		end
	end)
	if hasOxTarget then
		exports.ox_target:addLocalEntity(veh, {
			{ name = "ujt_garagem_retrieve_" .. item.id, icon = "fas fa-car", label = "Retirar veículo", distance = 3.0,
			  onSelect = function() TriggerServerEvent("ujt_garagem:retrieve", item.id) end },
		})
	end
end

local function showGarage()
	clearDisplays()
	if not myGarage.entrance then return end
	local stored = vSERVER.getStored() or {}
	for _, item in ipairs(stored) do spawnDisplay(item) end
	shown = true
end

RegisterNetEvent("ujt_garagem:refresh", function()
	local p = GetEntityCoords(PlayerPedId())
	if myGarage.entrance and #(p - vector3(myGarage.entrance.x, myGarage.entrance.y, myGarage.entrance.z)) < Config.DisplayRadius then
		showGarage()
	end
end)

-- ---------------------------------------------------------------------------
-- Blip da entrada
-- ---------------------------------------------------------------------------
local function refreshBlip()
	if myBlip and DoesBlipExist(myBlip) then RemoveBlip(myBlip) myBlip = nil end
	if hasOxTarget and entranceZone then exports.ox_target:removeZone(entranceZone) entranceZone = nil end
	if myGarage.entrance then
		local e = myGarage.entrance
		myBlip = AddBlipForCoord(e.x, e.y, e.z)
		SetBlipSprite(myBlip, Config.Blip.sprite or 357); SetBlipColour(myBlip, Config.Blip.color or 3)
		SetBlipScale(myBlip, Config.Blip.scale or 0.9); SetBlipAsShortRange(myBlip, true)
		BeginTextCommandSetBlipName("STRING"); AddTextComponentString(Config.Blip.label or "Garagem"); EndTextCommandSetBlipName(myBlip)

		-- Zona ox_target na entrada pra guardar (só quando estiver de veículo)
		if hasOxTarget then
			local dist = Config.InteractDist or 2.5
			entranceZone = exports.ox_target:addBoxZone({
				coords = vector3(e.x, e.y, e.z),
				size = vector3(dist * 2.0, dist * 2.0, 3.0),
				rotation = e.w or 0.0,
				debug = false,
				options = {
					{ name = "ujt_garagem_store", icon = "fas fa-warehouse", label = "Guardar veículo", distance = dist,
					  canInteract = function() return GetVehiclePedIsIn(PlayerPedId(), false) ~= 0 end,
					  onSelect = function() if storeCurrent then storeCurrent() end end },
					{ name = "ujt_garagem_open", icon = "fas fa-list", label = "Abrir garagem", distance = dist,
					  canInteract = function() return GetVehiclePedIsIn(PlayerPedId(), false) == 0 end,
					  onSelect = function() if openPanel then openPanel() end end },
				},
			})
		end
	end
end

-- ---------------------------------------------------------------------------
-- Guardar / retirar
-- ---------------------------------------------------------------------------
storeCurrent = function()
	local ped = PlayerPedId()
	local veh = GetVehiclePedIsIn(ped, false)
	if veh == 0 then return notify("negado", "Entre no veículo que quer guardar.") end
	if GetPedInVehicleSeat(veh, -1) ~= ped then return notify("negado", "Você precisa estar no motorista.") end
	local props = getProps(veh)
	-- identidade = modelo + id do player (a placa NÃO é usada como identidade)
	TriggerServerEvent("ujt_garagem:store", { model = props.model, props = props })
	Wait(300)
	deleteVehClean(veh) -- remove os acessórios do bs_montasom junto (não deixa órfão)
end

RegisterNetEvent("ujt_garagem:spawnDrivable", function(data)
	local e = myGarage.entrance or { x = GetEntityCoords(PlayerPedId()).x, y = GetEntityCoords(PlayerPedId()).y, z = GetEntityCoords(PlayerPedId()).z, w = 0.0 }
	local hash = loadModel(data.props and data.props.model or data.model)
	if not hash then return notify("negado", "Falha ao carregar o modelo.") end
	local veh = CreateVehicle(hash, e.x, e.y, e.z, e.w or 0.0, true, false)
	local t = 0
	while not DoesEntityExist(veh) and t < 100 do Wait(10) t = t + 1 end
	SetVehicleOnGroundProperly(veh); applyProps(veh, data.props)
	SetVehicleDoorsLocked(veh, 1); SetVehicleHasBeenOwnedByPlayer(veh, true)
	SetModelAsNoLongerNeeded(hash)
	TaskWarpPedIntoVehicle(PlayerPedId(), veh, -1)
	-- reaplica os acessórios do bs_montasom no carro retirado (por dono + modelo)
	SetTimeout(900, function()
		if DoesEntityExist(veh) then
			TriggerServerEvent("bs_montasom:loadForOwner", VehToNet(veh), GetDisplayNameFromVehicleModel(GetEntityModel(veh)))
		end
	end)
end)

-- ---------------------------------------------------------------------------
-- Carrega a config do jogador ao iniciar
-- ---------------------------------------------------------------------------
CreateThread(function()
	Wait(1500)
	local cfg = vSERVER.getConfig()
	myGarage.entrance = cfg.entrance
	myGarage.spots = cfg.spots or {}
	refreshBlip()
end)

-- ---------------------------------------------------------------------------
-- Loop de exibição + interação de guardar
-- ---------------------------------------------------------------------------
CreateThread(function()
	local key = Config.MarkerKey
	while true do
		local sleep = 1000
		local ent = myGarage.entrance
		if ent then
			local p = GetEntityCoords(PlayerPedId())
			local d = #(p - vector3(ent.x, ent.y, ent.z))
			if d < Config.DisplayRadius then
				if not shown then showGarage() end

				if hasOxTarget then
					-- ox_target cuida da interação: só mantemos os carros exibidos (loop leve)
					sleep = 500
				elseif d < 18.0 then
					-- perto da entrada: precisa desenhar o marcador/textos (Wait(0))
					sleep = 0
					DrawMarker(1, ent.x, ent.y, ent.z - 0.95, 0,0,0, 0,0,0, 2.0,2.0,0.6, 70,160,255,120, false,true,2,false,nil,nil,false)
					local ped = PlayerPedId()
					if GetVehiclePedIsIn(ped, false) ~= 0 then
						if d < Config.InteractDist then
							drawText3D(vector3(ent.x, ent.y, ent.z + 0.6), "~b~[E]~w~ Guardar veículo")
							if IsControlJustPressed(0, key) then storeCurrent() end
						end
					else
						-- retirar a pé perto do carro estacionado
						for id, e in pairs(displays) do
							if e and DoesEntityExist(e) and #(p - GetEntityCoords(e)) < 3.5 then
								drawText3D(GetEntityCoords(e) + vector3(0, 0, 1.2), "~b~[E]~w~ Retirar veículo")
								if IsControlJustPressed(0, key) then TriggerServerEvent("ujt_garagem:retrieve", id) end
								break
							end
						end
					end
				else
					-- dentro do raio, mas longe da entrada: nada a desenhar
					sleep = 300
				end
			elseif shown then
				clearDisplays()
			end
		end
		Wait(sleep)
	end
end)

-- =========================================================================
-- MODO DE SETUP — definir entrada e vagas (com carro-fantasma)
-- =========================================================================
local setup = { active = false, entrance = nil, spots = {}, ghost = nil, ghostSpots = {} }

local function ghostClear()
	if setup.ghost and DoesEntityExist(setup.ghost) then DeleteEntity(setup.ghost) end
	setup.ghost = nil
	for _, e in ipairs(setup.ghostSpots) do if e and DoesEntityExist(e) then DeleteEntity(e) end end
	setup.ghostSpots = {}
end

local function spawnSpotGhost(spot, alpha)
	local hash = loadModel(Config.GhostModel)
	if not hash then return nil end
	local e = CreateVehicle(hash, spot.x, spot.y, spot.z, spot.w or 0.0, false, false)
	SetVehicleOnGroundProperly(e); FreezeEntityPosition(e, true); SetEntityCollision(e, false, false)
	SetEntityAlpha(e, alpha or 150, false); SetEntityInvincible(e, true)
	SetModelAsNoLongerNeeded(hash)
	return e
end

local function pushSetupNui()
	SendNUIMessage({ action = "setupUpdate", entrance = setup.entrance ~= nil, spots = #setup.spots, max = Config.MaxVehiclesPerPlayer })
end

local function exitSetup(save)
	if save then
		TriggerServerEvent("ujt_garagem:saveConfig", setup.entrance, setup.spots)
	else
		notify("aviso", "Setup cancelado (nada foi salvo).")
	end
	setup.active = false
	ghostClear()
	SendNUIMessage({ action = "setupClose" })
	SetNuiFocus(false, false)
end

RegisterNetEvent("ujt_garagem:configSaved", function(cfg)
	myGarage.entrance = cfg.entrance
	myGarage.spots = cfg.spots or {}
	refreshBlip()
	clearDisplays()
end)

local function startSetup()
	if setup.active then return end
	setup.active = true
	-- começa a partir da config atual
	setup.entrance = myGarage.entrance
	setup.spots = {}
	for _, s in ipairs(myGarage.spots or {}) do setup.spots[#setup.spots + 1] = { x = s.x, y = s.y, z = s.z, w = s.w } end
	-- ghosts das vagas já existentes
	for _, s in ipairs(setup.spots) do setup.ghostSpots[#setup.ghostSpots + 1] = spawnSpotGhost(s, 180) end
	clearDisplays()
	SendNUIMessage({ action = "setupOpen" })
	pushSetupNui()

	CreateThread(function()
		while setup.active do
			Wait(0)
			local ped = PlayerPedId()
			local fwd = GetEntityForwardVector(ped)
			local pos = GetEntityCoords(ped) + (fwd * (Config.GhostForward or 3.5))
			local h = GetEntityHeading(ped)

			-- fantasma segue à frente do jogador
			if not setup.ghost or not DoesEntityExist(setup.ghost) then setup.ghost = spawnSpotGhost({ x = pos.x, y = pos.y, z = pos.z, w = h }, 120) end
			if setup.ghost then
				SetEntityCoordsNoOffset(setup.ghost, pos.x, pos.y, pos.z, false, false, false)
				SetEntityHeading(setup.ghost, h)
				SetVehicleOnGroundProperly(setup.ghost)
			end

			-- dicas
			drawText3D(pos + vector3(0, 0, 1.6),
				"~g~[E]~w~ Add vaga   ~b~[G]~w~ Entrada   ~y~[Backspace]~w~ Remover última   ~p~[Delete]~w~ Limpar tudo   ~o~[Enter]~w~ Salvar   ~r~[ESC]~w~ Cancelar")

			if IsControlJustPressed(0, 38) then -- E: adicionar vaga
				-- rejeita vaga muito perto de outra (evita carros empilhados)
				local tooClose = false
				for _, s in ipairs(setup.spots) do
					if #(vector3(pos.x, pos.y, pos.z) - vector3(s.x, s.y, s.z)) < (Config.MinSpotDistance or 4.5) then
						tooClose = true break
					end
				end
				if tooClose then
					notify("negado", "Vaga muito perto de outra. Afaste o carro-fantasma e tente de novo.")
				elseif #setup.spots >= (Config.MaxVehiclesPerPlayer or 12) then
					notify("negado", "Limite de vagas atingido.")
				else
					local s = { x = pos.x, y = pos.y, z = pos.z, w = h }
					setup.spots[#setup.spots + 1] = s
					setup.ghostSpots[#setup.ghostSpots + 1] = spawnSpotGhost(s, 180)
					notify("sucesso", "Vaga " .. #setup.spots .. " adicionada.")
					pushSetupNui()
				end
			elseif IsControlJustPressed(0, 47) then -- G: definir entrada (posição do jogador)
				local pc = GetEntityCoords(ped)
				setup.entrance = { x = pc.x, y = pc.y, z = pc.z, w = h }
				notify("sucesso", "Entrada da garagem definida aqui.")
				pushSetupNui()
			elseif IsControlJustPressed(0, 194) then -- Backspace: remover última vaga
				if #setup.spots > 0 then
					local e = table.remove(setup.ghostSpots)
					if e and DoesEntityExist(e) then DeleteEntity(e) end
					setup.spots[#setup.spots] = nil
					notify("aviso", "Última vaga removida.")
					pushSetupNui()
				end
			elseif IsControlJustPressed(0, 191) then -- Enter: salvar
				if not setup.entrance then notify("negado", "Defina a ENTRADA (tecla G) antes de salvar.")
				elseif #setup.spots == 0 then notify("negado", "Adicione pelo menos 1 vaga (tecla E).")
				else exitSetup(true) end
			elseif IsControlJustPressed(0, 178) then -- Delete: limpar tudo (recomeçar do zero)
				setup.entrance = nil
				setup.spots = {}
				for _, e in ipairs(setup.ghostSpots) do if e and DoesEntityExist(e) then DeleteEntity(e) end end
				setup.ghostSpots = {}
				notify("aviso", "Setup limpo. Redefina a entrada (G) e as vagas (E).")
				pushSetupNui()
			elseif IsControlJustPressed(0, 322) then -- ESC: cancelar
				exitSetup(false)
			end
		end
	end)
end

-- ---------------------------------------------------------------------------
-- Comandos + NUI callbacks
-- ---------------------------------------------------------------------------
RegisterCommand(Config.SetupCommand, function() startSetup() end, false)

-- Nome amigável do modelo pro painel
local function modelLabel(model)
	local hash = tonumber(model) or GetHashKey(model)
	local gname = hash and GetDisplayNameFromVehicleModel(hash) or "VEÍCULO"
	local label = GetLabelText(gname)
	if not label or label == "" or label == "NULL" then label = gname end
	return label
end

openPanel = function()
	if not myGarage.entrance then
		return notify("aviso", "Você ainda não montou sua garagem. Use /" .. Config.SetupCommand .. ".")
	end
	local p = GetEntityCoords(PlayerPedId())
	if #(p - vector3(myGarage.entrance.x, myGarage.entrance.y, myGarage.entrance.z)) > Config.DisplayRadius then
		return notify("aviso", "Vá até a sua garagem para abrir o painel.")
	end
	if not shown then showGarage() end

	local stored = vSERVER.getStored() or {}
	local list = {}
	for _, v in ipairs(stored) do
		list[#list + 1] = { id = v.id, label = modelLabel(v.props and v.props.model or v.model), spot = (v.spot or 0) + 1 }
	end
	SetNuiFocus(true, true)
	SendNUIMessage({ action = "panelOpen", vehicles = list, used = #list, total = #(myGarage.spots or {}) })
end

RegisterCommand(Config.OpenCommand, function() openPanel() end, false)

RegisterNUICallback("panelClose", function(_, cb)
	SetNuiFocus(false, false)
	SendNUIMessage({ action = "panelClose" })
	cb("ok")
end)

RegisterNUICallback("panelRetrieve", function(data, cb)
	SetNuiFocus(false, false)
	SendNUIMessage({ action = "panelClose" })
	if data and data.id then TriggerServerEvent("ujt_garagem:retrieve", data.id) end
	cb("ok")
end)

RegisterCommand(Config.DeleteCommand, function(_, args)
	local wipe = (args[1] and args[1]:lower() == "tudo")
	TriggerServerEvent("ujt_garagem:deleteGarage", wipe)
end, false)

RegisterNUICallback("close", function(_, cb) exitSetup(false); cb("ok") end)

AddEventHandler("onResourceStop", function(res)
	if res == GetCurrentResourceName() then clearDisplays(); ghostClear() end
end)
