-- =========================================================================
-- ujt_garagem — CONFIGURAÇÃO
-- NÃO há coordenadas fixas: cada jogador define a própria garagem no jogo.
-- =========================================================================
Config = {}

Config.Locale        = "pt-BR"
Config.OpenCommand   = "garagem"        -- exibe/gerencia a garagem
Config.SetupCommand  = "garagemsetup"   -- painel para DEFINIR as coordenadas
Config.DeleteCommand = "garagemapagar"  -- apaga a garagem (use "tudo" pra apagar os carros também)
Config.UseOxTarget   = true             -- retirar carro via ox_target (senão marker)
Config.MarkerKey     = 38               -- tecla E
Config.DisplayRadius = 60.0             -- distância pra exibir os carros estacionados
Config.InteractDist  = 2.5              -- distância pra poder GUARDAR o carro (menor = tem que chegar mais perto)

Config.MaxVehiclesPerPlayer = 12        -- máx. de carros guardados por jogador
Config.MinSpotDistance      = 4.5       -- distância mínima entre vagas (evita carros empilhados)

-- Carro "fantasma" usado no setup pra você ver onde a vaga vai ficar
Config.GhostModel   = "sultan"
Config.GhostForward = 3.5               -- distância à frente do jogador onde o fantasma aparece

-- Blip da entrada da garagem do jogador
Config.Blip = { sprite = 357, color = 3, scale = 0.9, label = "Minha Garagem" }

-- Notificação (ajuste pro seu sistema)
Config.Notify = function(source, typ, msg, time)
	TriggerClientEvent("Notify", source, typ or "aviso", msg or "", time or 4000)
end
