-- =========================================================================
-- ujt_garagem — SERVER
-- Sistema próprio por jogador: guarda a CONFIG (entrada + vagas que o jogador
-- define) e os VEÍCULOS guardados. Sem conflito com outros sistemas.
-- =========================================================================
local Tunnel = module("vrp", "lib/Tunnel")
local Proxy = module("vrp", "lib/Proxy")
vRP = Proxy.getInterface("vRP")

local src = {}
Tunnel.bindInterface("ujt_garagem", src)

local function notify(source, typ, msg, time)
	if Config.Notify then Config.Notify(source, typ, msg, time) end
end

local function q(sql, params)
	local ok, res = pcall(MySQL.query.await, sql, params or {})
	if not ok then print("^1[ujt_garagem][DB] " .. tostring(res) .. "^7") return {} end
	return res or {}
end

-- ---------------------------------------------------------------------------
-- Banco
-- ---------------------------------------------------------------------------
CreateThread(function()
	q([[
		CREATE TABLE IF NOT EXISTS ujt_garagem_config (
			owner_id INT NOT NULL,
			entrance LONGTEXT DEFAULT NULL,
			spots LONGTEXT DEFAULT NULL,
			updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY (owner_id)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
	]])
	q([[
		CREATE TABLE IF NOT EXISTS ujt_garagem_vehicles (
			id INT NOT NULL AUTO_INCREMENT,
			owner_id INT NOT NULL,
			model VARCHAR(60) NOT NULL,
			plate VARCHAR(12) DEFAULT NULL,
			props LONGTEXT DEFAULT NULL,
			spot INT NOT NULL DEFAULT 0,
			stored_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id),
			KEY owner_idx (owner_id)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
	]])
	print("^2[ujt_garagem] Banco verificado.^7")
end)

-- ---------------------------------------------------------------------------
-- Config do jogador (entrada + vagas)
-- ---------------------------------------------------------------------------
local function getConfig(user_id)
	local rows = q("SELECT entrance, spots FROM ujt_garagem_config WHERE owner_id = ? LIMIT 1", { user_id })
	local r = rows[1]
	return {
		entrance = (r and r.entrance and json.decode(r.entrance)) or nil,
		spots = (r and r.spots and json.decode(r.spots)) or {},
	}
end

src.getConfig = function()
	local user_id = vRP.getUserId(source)
	if not user_id then return { entrance = nil, spots = {} } end
	return getConfig(user_id)
end

RegisterNetEvent("ujt_garagem:saveConfig", function(entrance, spots)
	local source = source
	local user_id = vRP.getUserId(source)
	if not user_id then return end
	if type(spots) ~= "table" then spots = {} end
	-- limita ao máximo de vagas
	local max = Config.MaxVehiclesPerPlayer or 12
	if #spots > max then for i = #spots, max + 1, -1 do spots[i] = nil end end

	MySQL.query.await([[
		INSERT INTO ujt_garagem_config (owner_id, entrance, spots) VALUES (?, ?, ?)
		ON DUPLICATE KEY UPDATE entrance = VALUES(entrance), spots = VALUES(spots)
	]], { user_id, entrance and json.encode(entrance) or nil, json.encode(spots) })

	notify(source, "sucesso", "Garagem salva! Entrada e " .. #spots .. " vaga(s) definidas.")
	TriggerClientEvent("ujt_garagem:configSaved", source, { entrance = entrance, spots = spots })
end)

-- ---------------------------------------------------------------------------
-- Veículos guardados
-- ---------------------------------------------------------------------------
local function getStored(user_id)
	local rows = q("SELECT id, model, props, spot FROM ujt_garagem_vehicles WHERE owner_id = ? ORDER BY spot ASC, id ASC", { user_id })
	local list = {}
	for _, r in ipairs(rows) do
		list[#list + 1] = { id = r.id, model = r.model, spot = r.spot, props = (r.props and json.decode(r.props)) or {} }
	end
	return list
end

src.getStored = function()
	local user_id = vRP.getUserId(source)
	if not user_id then return {} end
	return getStored(user_id)
end

local function firstFreeSpot(user_id, maxSpots)
	local rows = q("SELECT spot FROM ujt_garagem_vehicles WHERE owner_id = ?", { user_id })
	local used = {}
	for _, r in ipairs(rows) do used[tonumber(r.spot)] = true end
	for i = 0, maxSpots - 1 do if not used[i] then return i end end
	return nil
end

RegisterNetEvent("ujt_garagem:store", function(data)
	local source = source
	local user_id = vRP.getUserId(source)
	if not user_id or type(data) ~= "table" or not data.model then return end

	local cfg = getConfig(user_id)
	local spots = cfg.spots or {}
	if #spots == 0 then return notify(source, "negado", "Defina as vagas da sua garagem primeiro (/" .. Config.SetupCommand .. ").") end

	local count = tonumber(MySQL.scalar.await("SELECT COUNT(*) FROM ujt_garagem_vehicles WHERE owner_id = ?", { user_id })) or 0
	if count >= #spots then return notify(source, "negado", "Sua garagem está cheia (todas as vagas ocupadas).") end

	local spot = firstFreeSpot(user_id, #spots)
	if spot == nil then return notify(source, "negado", "Não há vaga livre.") end

	-- identidade = owner_id + model (a placa NÃO é gravada como identidade)
	MySQL.query.await("INSERT INTO ujt_garagem_vehicles (owner_id, model, props, spot) VALUES (?, ?, ?, ?)",
		{ user_id, tostring(data.model), json.encode(data.props or {}), spot })
	notify(source, "sucesso", "Veículo guardado na garagem.")
	TriggerClientEvent("ujt_garagem:refresh", source)
end)

-- Apagar a garagem (config). Bloqueia se houver carros, a menos que wipeVehicles=true
RegisterNetEvent("ujt_garagem:deleteGarage", function(wipeVehicles)
	local source = source
	local user_id = vRP.getUserId(source)
	if not user_id then return end

	local count = tonumber(MySQL.scalar.await("SELECT COUNT(*) FROM ujt_garagem_vehicles WHERE owner_id = ?", { user_id })) or 0
	if count > 0 and not wipeVehicles then
		return notify(source, "negado",
			"Você tem " .. count .. " carro(s) guardado(s). Retire todos antes, ou use /" .. (Config.DeleteCommand or "garagemapagar") .. " tudo.")
	end

	if wipeVehicles then MySQL.query.await("DELETE FROM ujt_garagem_vehicles WHERE owner_id = ?", { user_id }) end
	MySQL.query.await("DELETE FROM ujt_garagem_config WHERE owner_id = ?", { user_id })

	notify(source, "sucesso", "Garagem apagada. Monte uma nova com /" .. (Config.SetupCommand or "garagemsetup") .. ".")
	TriggerClientEvent("ujt_garagem:configSaved", source, { entrance = nil, spots = {} })
end)

RegisterNetEvent("ujt_garagem:retrieve", function(vehId)
	local source = source
	local user_id = vRP.getUserId(source)
	if not user_id then return end
	vehId = tonumber(vehId)
	if not vehId then return end

	local rows = q("SELECT id, model, props FROM ujt_garagem_vehicles WHERE id = ? AND owner_id = ? LIMIT 1", { vehId, user_id })
	local v = rows[1]
	if not v then return notify(source, "negado", "Veículo não encontrado.") end

	MySQL.query.await("DELETE FROM ujt_garagem_vehicles WHERE id = ? AND owner_id = ?", { vehId, user_id })
	TriggerClientEvent("ujt_garagem:spawnDrivable", source, { model = v.model, props = (v.props and json.decode(v.props)) or {} })
	TriggerClientEvent("ujt_garagem:refresh", source)
	notify(source, "sucesso", "Veículo retirado.")
end)

-- ---------------------------------------------------------------------------
-- Integração com skips_garagem
-- Quando o jogador tira um carro de OUTRA garagem (skips_garagem), esse mesmo
-- modelo é removido da garagem pessoal (ujt_garagem) para não ficar duplicado.
-- Casamento por owner_id + hash do modelo (o server tem placas duplicadas, então
-- placa não serve como identidade). A comparação é numérica normalizada para não
-- depender do formato (int/float) com que o hash foi salvo.
-- ---------------------------------------------------------------------------
RegisterNetEvent("ujt_garagem:externalTakeout", function(modelHash)
	local source = source
	local user_id = vRP.getUserId(source)
	if not user_id then return end
	local target = math.floor(tonumber(modelHash) or 0)
	if target == 0 then return end

	local rows = q("SELECT id, model FROM ujt_garagem_vehicles WHERE owner_id = ?", { user_id })
	local removed = 0
	for _, r in ipairs(rows) do
		if math.floor(tonumber(r.model) or 0) == target then
			MySQL.query.await("DELETE FROM ujt_garagem_vehicles WHERE id = ?", { r.id })
			removed = removed + 1
		end
	end

	if removed > 0 then
		TriggerClientEvent("ujt_garagem:refresh", source)
		notify(source, "aviso", "Este veículo saiu da sua garagem pessoal (foi retirado de outra garagem).")
	end
end)

print("^2[ujt_garagem] Server carregado.^7")
